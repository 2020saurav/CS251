matrix(101,13)=0;
matrix(1,1)=10000 + (ceil(rand*1000));
for j=1:100
	matrix(j+1,1)=matrix(j,1)+1;
	matrix(j,2) = 1+ mod(1+floor(rand*10),9);
	matrix(j,3) = 1+ mod(1+floor(rand*10),9);
	while(matrix(j,3)==matrix(j,2))
		matrix(j,3) = 1+ mod(1+floor(rand*10),9);
	endwhile
	
	matrix(j,4) = 1+ mod(1+floor(rand*10),9);
	while(matrix(j,4)==matrix(j,2) || matrix(j,4)==matrix(j,3))
		matrix(j,4) = 1+ mod(1+floor(rand*10),9);
	endwhile
	for i=5:13
		matrix(j,i)= floor(mod(rand*100,51));
	endfor
	for i=1:12
		printf('%i, ', matrix(j,i));
	endfor
	printf('%i\n',matrix(j,13));
	
endfor

