#!/usr/bin/perl
use strict;
use warnings;
use Switch;
use vars;

`touch query.sql`;

my $query=" create table marks (roll integer, course integer, assignment integer, project integer, exam integer,
   primary key (roll, course)
   );";
my $q= " insert into marks values (";


my $file1="phase1.out";

open(my $data, '<', $file1) or die "Error occured in opening phase1.out\n";
while(my $line = <$data>)
{

	chomp $line;
	my @fields = split ",", $line;
	$query = $query.$q.$fields[0].",".$fields[1].",".$fields[4].",".$fields[5].",".$fields[6].");";
	$query = $query.$q.$fields[0].",".$fields[2].",".$fields[7].",".$fields[8].",".$fields[9].");";
	$query = $query.$q.$fields[0].",".$fields[3].",".$fields[10].",".$fields[11].",".$fields[12].");";

}

my $file5="phase1.out";

open(my $data5, '<', $file5) or die "Error occured in opening phase1.out\n";
my $line = <$data5>;
chomp $line;
my @fields = split ",", $line;
my $startroll = $fields[0];



# used http://perlmaven.com/how-to-read-a-csv-file-using-perl

open(file2, ">query.sql");
print file2 "use test;".$query;

print `mysql <query.sql`;
close(file2);
system " rm query.sql ";


my $query2=" create table names (roll integer primary key, name varchar(40));";
my $q2= " insert into names values (";

my $file3="names.txt";
open(my $data2, '<', $file3) or die "Error occured in opening names.txt\n";
my $i=0;
while(my $line = <$data2>)
{
	chomp $line;
	$query2 = $query2.$q2.($startroll+$i).", \"".$line."\");";
	$i++;	

}
open(file4, ">query1.sql");
print file4 "use test;".$query2;

print `mysql <query1.sql`;
close(file2);
system " rm query1.sql ";
