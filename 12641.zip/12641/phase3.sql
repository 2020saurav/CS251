use test;

alter table marks add total integer NOT NULL;

alter table marks add grade varchar(3) NOT NULL;

update marks set total = assignment+project+exam;
update marks set grade = "A" where (total<143);
update marks set grade = "B" where (total<120);
update marks set grade = "C" where (total<90);
update marks set grade = "D" where (total<68);
update marks set grade = "F" where (total<45);
update marks set grade = "A*" where (total>=143);

select course, grade, count(grade) from marks group by course, grade;

