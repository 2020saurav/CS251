echo "Final Assignment\n

Select 1 for running Octave Phase\n
Select 2 for running Perl Phase\n
Select 3 for running Mysql Phase\n
Select 5 for running Gnuplot Phase\n
Select 6 for running Latex Phase\n
Select 7 for running All Phase\n

";

read a;

if [ $a == 1 ];
	then 
	octave phase1.m > phase1.out
#Please delete the top part of Octave!
fi

if [ $a == 2 ];
	then 
	perl phase.pl
fi

if [ $a == 3 ];
	then 
	mysql < phase3.sql
fi
if [ $a == 5 ];
	then 
	gnome-open phase5.pdf
fi
if [ $a == 6 ];
	then 
	gnome-open phase6.pdf
fi
if [ $a == 7 ];
	then 
	
fi
