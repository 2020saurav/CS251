# boxplot of max, min, median, 25th percentile and 75th percentile.
# data : 5x 7 matrix: write this out
N=1;
for n = 1:7			# will do for N = 10,100,1000
	N = 10*N;
	
	
	for j=1:10 		#j = trial number
		M=0;
		
		mat=rand(N,2);
		mat=mat.*2;
		mat=mat.-1;
		sqsum=sumsq(mat');
		mfloor=floor(sqsum);
		M=sum(sum(mfloor==0));

		pi=(4*M/N);
		a(j,n)=pi;


	endfor
# min | max | median | 25 qtl | 75 qtl | mean
b(1,n)=min(a(:,n));
b(2,n)=max(a(:,n));
b(3,n)=median(a(:,n));
b(4,n)=prctile(a(:,n),25);
b(5,n)=prctile(a(:,n),75);
b(6,n)=mean(a(:,n));	
endfor
file_id = fopen('output.txt','w');
fdisp(file_id, b);
fclose(file_id);

axis ([1,5,2,5]);
 boxplot ({b(:,1),b(:,2),b(:,3),b(:,4),b(:,5),b(:,6),b(:,7)});
 set(gca (), "xtick", [1:7], "xticklabel", {"1", "2","3","4","5","6","7"})
 title ("Value of Pi");
 print -depsc boxplot1.eps

h=0;
k=0;
l=0;
m=0;
n=0;
o=0;
p=0;
q=0;
r=0;


	for i=1:7
	x=b(6,i);

	if (x<=2.9 && x>0)
	h+=1;
	end

	if (x<=3.0 && x>2.9)
	l+=1;
	end

	if (x<=3.1 && x>3.0)
	m+=1;
	end

	if (x<=3.2 && x>3.1)
	n+=1;
	end

	if (x<=3.3 && x>3.2)
	o+=1;
	end

	if (x<=3.4 && x>3.3)
	p+=1;
	end

	if (x<=3.5 && x>3.4)
	q+=1;
	end

	if (x<=10.0 && x>3.5)
	r+=1;
	end

	
	endfor


var=[2.8,h;2.9,l;3.0,m;3.1,n;3.2,o;3.3,p;3.4,q;3.5,r]
save "histo1.txt" var;




