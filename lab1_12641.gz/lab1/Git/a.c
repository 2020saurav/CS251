#include<stdio.h>
int main()
{
int a,b;
scanf("%d%d",&a,&b);
//editing a cloned file from a different system, but my folder..
printf("%d\n",a-b);
printf("%f\n",a/b);
return 0;
}
