#include <stdio.h>

int main()
{
int a,b;
scanf("%d%d",&a,&b);
// Comment
printf("%d",a+b);
return 0;
}
